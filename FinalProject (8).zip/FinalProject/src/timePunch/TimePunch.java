package timePunch;

public class TimePunch {
	public static void main(String[] args) {
		
}}
