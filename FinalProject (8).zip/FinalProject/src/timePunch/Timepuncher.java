package timePunch;
import timePunch.EmpInfo;
import java.util.Scanner;
public class Timepuncher {
	//Missing variable values due to my not knowing how/ unsuccessful attempts at calling a class
	//Intent: To call the main body of the EmpInfo class to run here in this class.
	public static void main(String[] args) {
		EmpInfo c = new EmpInfo(); 
		c.EmpI(); 
;
	 {
}}}
