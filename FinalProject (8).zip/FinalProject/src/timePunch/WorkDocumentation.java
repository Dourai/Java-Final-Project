package timePunch;
import java.util.Scanner;


public class WorkDocumentation {

			//Missing variable values due to my not knowing how/ unsuccessful attempts at calling a class
	public static void main(String[] args) {
		try (Scanner myInput = new Scanner( System.in )) {
			String newline = System.getProperty("line seperator");		
			float DaysWorked = 5;
			float HoursWorkedWeek = 45;	
			double Wage = 32.60;
			double HoursWorkedToday = 8.5;
			String Salary = "$75,000";
			String Position = "Head of Development";
			String StartDate = "October 12th 2020";
			String DocumentedRaises = "One raise was granted. $3 raise in June of 2021.";
			
			System.out.print(HoursWorkedToday + newline + DaysWorked + newline + HoursWorkedWeek + newline + Wage + newline +Salary + newline + Position + newline + StartDate + newline + DocumentedRaises );
}}}
