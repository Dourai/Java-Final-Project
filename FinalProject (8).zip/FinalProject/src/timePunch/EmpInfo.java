package timePunch;
import java.util.Scanner;

import javax.print.DocFlavor.STRING;

public class EmpInfo {
	EmpInfo c = new EmpInfo();
	static float Timein;


	public static void main(String[] args) {

		
		double info = 0;
		
		EmpInfo Timein = new EmpInfo();

	}
			
			  public static String EmpI(double info) {
					String firstName = "";
					String lastName = "";
					String validFirst1 = "Daniel";
					String validLast1 = "Ourai";
					String validFirst2 = "Jim";
					String validLast2 = "Johnson";
					String fullName = firstName + " " + lastName;
					String Confirm = "";	
					float Timein = 0;
					double Timeback = Timein + 0.30;
					float Timeout;
					float Endshift;
					double ret = 0;
					int Direct = 0;
					try (Scanner myInput = new Scanner( System.in )) {
						//Collect Employee first name
  					System.out.println("Please enter your first name.");
						firstName = myInput.next();
					 	 while (!firstName.equals(validFirst1) && !firstName.equals(validFirst2)) {
						 		System.out.println("ERROR... Please enter a valid first name.");
						 		firstName = myInput.next();
						 		 EmployeeName (fullName); {
						 			 return fullName;
					 	 }
					 	//Collect Employee last name
						 		   if (firstName.equals(validFirst1) && firstName.equals(validFirst2)) {                     
								System.out.println("Please enter your last name.");
								lastName = myInput.next();
						 		 }
								
							
								 while (!lastName.equals(validLast1) && !lastName.equals(validLast2)) {
								 		System.out.println("ERROR... Please enter a valid last name.");
								 		firstName = myInput.next();

								 }
								 //Name confirmation
									while(!Confirm.equals("yes")) {
										System.out.println("To continue, type yes to confirm that your name is " + firstName + " " + lastName);
										Confirm = myInput.next();
										if(!Confirm.equals("yes")) {
											System.out.println("Confirmation failed. Please try again." );
										}
											else {
												System.out.println("Welcome " + firstName + ". To clock in, type 1. To clock out for break, type 2 or type 3 to end your shift." );
												Direct = myInput.nextInt();
											}				
										// Prompt user to clock in

												if (Direct == 1) {	
													System.out.println("Please enter the current time (use a period in place of the colon)." );
													Timein = myInput.nextFloat();
													System.out.print("Clock-in successful. Enjoy your shift!" );

												}}
									//Prompt user to clock out for break
													if (Direct == 2) {
														System.out.println("Please enter the current time (use a period in place of the colon)." );
														Timeout = myInput.nextFloat();
														System.out.print("Clock-out successful. See you at " + Timeback +  "!" );
													}
									//Prompt user to end their shift.
														if (Direct == 3) {
															System.out.println("Please enter the current time (use a period in place of the colon)." );
															Endshift = myInput.nextFloat();
															System.out.print("Shift successfully ended." );
															
														}
													}
												

										
									
							
										
									
								
	return fullName;
			  }}
					



					
			 

			    
public static Object Intime(float timein) {
				// TODO Auto-generated method stub
				return null;
			}

private static void EmployeeName(String fullName) {
				// TODO Auto-generated method stub
				
			}

private static void EmployeeInfo(String fullName, float timein, float timeout) {
				// TODO Auto-generated method stub
				
			}

private static void EmployeeInfo(String fullName) {
				// TODO Auto-generated method stub
				
			}

public static String EmpIStore(double info) {
	 String fullName = "";
	EmpI(info);
return fullName;

}}
