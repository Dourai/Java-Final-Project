package timePunch;

public record Info() {

}
