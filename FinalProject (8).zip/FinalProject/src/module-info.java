/**
 * 
 */
/**
 * @author Danny
 *
 */
module FinalProject {
	requires java.desktop;
}